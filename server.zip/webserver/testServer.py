import requests

payload = {
    'id' : 73923,
    'number' : 384924034,
    'email' : 'bunnefant@gmail.com'
}
r = requests.post("http://localhost:5000/login", data=payload)
print(r.text)
